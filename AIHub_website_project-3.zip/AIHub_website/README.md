# AIHub — static website starter

## Included
- Responsive English-language homepage for mobile and desktop
- Search and category filters
- Favorite tools saved in local browser storage
- 12 working browser-side utilities: word counter, case converter, percentage calculator, length converter, reading-time estimate, text cleaner, tip/bill split, random number generator, BMI calculator, password generator, JSON formatter, and discount calculator
- Basic SEO/social metadata and a web app manifest
- A small service worker for basic offline caching when hosted over HTTPS

## Run locally
Open `index.html` in a modern browser. Most tools work locally. The service worker only registers on a web server (for example HTTPS/localhost).

## Publish
Upload `index.html`, `manifest.webmanifest`, and `sw.js` to a static hosting provider that is available to you. Test availability, terms, and access from your location before choosing a provider.

## Important limitations
- This is a static starter website, not yet a revenue-generating business.
- It has no ad network integration, no server/backend, no user accounts, and no AI API calls.
- Do not add ads until an ad provider has approved the site and confirmed that its payment terms are compatible with your actual residence and legal status.
- Revenue is not guaranteed. Do not use false identity, false residency, or another person's payment account to bypass provider restrictions.
- Add a real privacy policy, terms, contact details, and any legally required disclosures before public monetization.
- Password generation happens in the browser; for critical accounts, use a reputable dedicated password manager.
- BMI output is informational only and not medical advice.
